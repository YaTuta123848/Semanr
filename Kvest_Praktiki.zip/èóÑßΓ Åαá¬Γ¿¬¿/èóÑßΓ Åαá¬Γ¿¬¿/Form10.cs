﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Квест_Практики
{
    public partial class Form10 : Form
    {
        static int hp = 0;
        static int damage;
        Hero hero = new Hero(hp, damage);
        public Form10()
        {
            InitializeComponent();
            Hp.Text = "Hp = " + Convert.ToString(hero.Hp);
            Damage.Text = "Dmg = " + Convert.ToString(hero.Damage);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Lose lose = new Lose();
            lose.StartPosition = FormStartPosition.CenterScreen;
            lose.Show();
            this.Hide();
        }
    }
}
