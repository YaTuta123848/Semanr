﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Квест_Практики
{
    public partial class Form11 : Form
    {
        static int hp;
        static int damage;
        Hero hero = new Hero(hp, damage);
        public Form11()
        {
            InitializeComponent();
            Hp.Text = "Hp = " + Convert.ToString(hero.Hp);
            Damage.Text = "Dmg = " + Convert.ToString(hero.Damage);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Win win = new Win();
            win.StartPosition = FormStartPosition.CenterScreen;
            win.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form10 frm10 = new Form10();
            frm10.StartPosition = FormStartPosition.CenterScreen;
            frm10.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form12 frm12 = new Form12();
            frm12.StartPosition = FormStartPosition.CenterScreen;
            frm12.Show();
            this.Hide();
        }

        private void Form11_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }
    }
}
