﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Квест_Практики
{
    public partial class Form9 : Form
    {
        static int hp;
        static int damage;
        Hero hero = new Hero(hp, damage);
        public Form9()
        {
            InitializeComponent();
            Hp.Text = "Hp = " + Convert.ToString(hero.Hp-5);
            Damage.Text = "Dmg = " + Convert.ToString(hero.Damage);
            hero.Hp -= 5;
            //if (hero.Hp < 0)
            //{
            //    Lose lose = new Lose();
            //    lose.StartPosition = FormStartPosition.CenterScreen;
            //    lose.Show();
            //}
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form10 frm10 = new Form10();
            frm10.StartPosition = FormStartPosition.CenterScreen;
            frm10.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form11 frm11 = new Form11();
            frm11.StartPosition = FormStartPosition.CenterScreen;
            frm11.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form12 frm12 = new Form12();
            frm12.StartPosition = FormStartPosition.CenterScreen;
            frm12.Show();
            this.Hide();
        }

        private void Form9_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }
    }
}
