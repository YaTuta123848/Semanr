﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Квест_Практики
{
    public partial class Form4 : Form
    {
        static int hp;
        static int damage;
        Hero hero = new Hero(hp, damage);
        public Form4()
        {
            InitializeComponent();
            hero.Damage = 10;
            Hp.Text = "Hp = " + Convert.ToString(hero.Hp);
            Damage.Text = "Dmg = " + Convert.ToString(hero.Damage);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form5 frm5 = new Form5();
            frm5.StartPosition = FormStartPosition.CenterScreen;
            frm5.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form6 frm6 = new Form6();
            frm6.StartPosition = FormStartPosition.CenterScreen;
            frm6.Show();
            this.Hide();
        }

        private void Form4_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }
    }
}
