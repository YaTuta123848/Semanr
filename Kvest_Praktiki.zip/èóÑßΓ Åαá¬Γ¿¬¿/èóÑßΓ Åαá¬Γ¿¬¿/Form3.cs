﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Квест_Практики
{
    public partial class Form3 : Form
    {
        private void Hp_Click(object sender, EventArgs e)
        {
             
        }
        static int hp;
        static int damage;
        Hero hero = new Hero(hp,damage);
        
        public Form3()
        {
            InitializeComponent();
            hero.Hp -= 4;
            label2.Text = "Hp = " + Convert.ToString(hero.Hp);
            label3.Text = "Dmg = " + Convert.ToString(hero.Damage);
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form5 frm5 = new Form5();
            frm5.StartPosition = FormStartPosition.CenterScreen;
            frm5.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form6 frm6 = new Form6();
            frm6.StartPosition = FormStartPosition.CenterScreen;
            frm6.Show();
            this.Hide();
        }

        private void Form3_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }
    }

}
