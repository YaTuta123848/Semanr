﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Квест_Практики
{
    public partial class Form8 : Form
    {
        static int hp = 15;
        static int damage;
        Hero hero = new Hero(hp, damage);
        public Form8()
        {
            InitializeComponent();
            Hp.Text = "Hp = " + Convert.ToString(hero.Hp);
            Damage.Text = "Dmg = " + Convert.ToString(hero.Damage);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form8_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form7 frm7 = new Form7();
            frm7.StartPosition = FormStartPosition.CenterScreen;
            frm7.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form9 frm9 = new Form9();
            frm9.StartPosition = FormStartPosition.CenterScreen;
            frm9.Show();
            this.Hide();
        }
    }
}
