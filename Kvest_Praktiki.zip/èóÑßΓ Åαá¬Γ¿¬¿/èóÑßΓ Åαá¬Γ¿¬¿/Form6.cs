﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Квест_Практики
{
    public partial class Form6 : Form
    {
        static int hp;
        static int damage;
        Hero hero = new Hero(hp, damage);
        public Form6()
        {
            InitializeComponent();
            Hp.Text = "Hp = " + Convert.ToString(hero.Hp);
            Damage.Text = "Dmg = " + Convert.ToString(hero.Damage);
            label1.Text += Convert.ToString((10 / hero.Damage) * 4);
            hero.Hp -= (10 / hero.Damage) * 4;
            //if (hero.Hp < 0)
            //{
            //    Lose lose = new Lose();
            //    lose.StartPosition = FormStartPosition.CenterScreen;
            //    lose.Show();
            //    this.Hide();
            //}
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form7 frm7 = new Form7();
            frm7.StartPosition = FormStartPosition.CenterScreen;
            frm7.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form8 frm8 = new Form8();
            frm8.StartPosition = FormStartPosition.CenterScreen;
            frm8.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form9 frm9 = new Form9();
            frm9.StartPosition = FormStartPosition.CenterScreen;
            frm9.Show();
            this.Hide();
        }

        private void Form6_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }
    }
}
