﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Квест_Практики
{
    public partial class Form13 : Form
    {
        static int hp;
        static int damage;
        Hero hero = new Hero(hp, damage);
        public Form13()
        {
            InitializeComponent();
            label2.Text = "Hp = " + Convert.ToString(hero.Hp);
            label3.Text = "Dmg = " + Convert.ToString(hero.Damage);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Win win = new Win();
            win.StartPosition = FormStartPosition.CenterScreen;
            win.Show();
            this.Hide();
        }

        private void Form13_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }
    }
}
