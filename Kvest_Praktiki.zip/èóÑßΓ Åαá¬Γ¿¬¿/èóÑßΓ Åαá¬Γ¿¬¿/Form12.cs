﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Квест_Практики
{
    public partial class Form12 : Form
    {
        static int hp;
        static int damage;
        Hero hero = new Hero(hp, damage);
        public Form12()
        {
            InitializeComponent();
            Hp.Text = "Hp = " + Convert.ToString(hero.Hp);
            Damage.Text = "Dmg = " + Convert.ToString(hero.Damage);
        }

        private void Form12_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Diagnostics.Process.GetCurrentProcess().Kill();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form13 frm13 = new Form13();
            frm13.StartPosition = FormStartPosition.CenterScreen;
            frm13.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form10 frm10 = new Form10();
            frm10.StartPosition = FormStartPosition.CenterScreen;
            frm10.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form11 frm11 = new Form11();
            frm11.StartPosition = FormStartPosition.CenterScreen;
            frm11.Show();
            this.Hide();
        }

        private void Hp_Click(object sender, EventArgs e)
        {

        }
    }
}
