﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Квест_Практики
{
    public class Hero
    {
        public int Hp = 10;
        public int Damage = 3;
        public Hero(int hp, int damage)
        {
            this.Hp = hp;
            this.Damage = damage;
        }
    }
}
